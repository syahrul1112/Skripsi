import cv2
import tkinter as tk
from tkinter import Label
from PIL import Image, ImageTk
import numpy as np

camera = 0 #Inisialisasi kamera dengan indeks 0 (kamera default) 
video = cv2.VideoCapture(camera, cv2.CAP_DSHOW) #kamera menyala

# Menggunakan detektor wajah Haar Cascade yang telah disediakan oleh metode viola-jones
faceDeteksi = cv2.CascadeClassifier('haarcascade_frontalface_default.xml') #mengload haar cascade

recognizer = cv2.face_LBPHFaceRecognizer.create() # Membuat pengenal wajah dengan metode LBPH
recognizer.read('datalatih/training.xml') #membaca model yang sudah dilatih

threshold = 80 # Ambang batas untuk kepercayaan pengenalan wajah
a = 0 # Variabel untuk menghitung jumlah frame yang telah diproses

# Membuat jendela aplikasi tkinter
root = tk.Tk()
root.title("Face Recognition")

# Membuat label untuk menampilkan citra
label = Label(root)
label.pack()

# Daftar kosong untuk menyimpan label sebenarnya dan label yang diprediksi
true_labels = []
predicted_labels = []

# Fungsi untuk menghitung histogram LBP dari citra wajah
def calculate_lbp_histogram(face):
    lbp_face = cv2.resize(face, (128, 128)) # mengubah ukuran citra menjadi (128x128) piksel
    lbp_face = cv2.cvtColor(lbp_face, cv2.COLOR_BGR2GRAY) # mengubah citra menjadi skala abu
    lbp_hist = cv2.calcHist([lbp_face], [0], None, [256], [0, 256]) # Menghitung histogram LBP dari citra wajah
    return lbp_hist

# Fungsi untuk memperbarui frame
def update_frame():
    global video
    global label

    check, frame = video.read() # Membaca frame dari kamera
    
    abu = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) # Mengubah frame ke citra skala abu-abu
    
    # Mendeteksi wajah dalam citra menggunakan Haar Cascade
    wajah = faceDeteksi.detectMultiScale(abu, scaleFactor=1.3, minNeighbors=5)
    
    # Loop melalui setiap wajah yang terdeteksi
    for (x, y, w, h) in wajah:
        face = abu[y:y+h, x:x+w]
        lbp_hist = calculate_lbp_histogram(frame[y:y+h, x:x+w]) # Menghitung histogram LBP dari citra wajah

        # Menghitung histogram LBPH
        hist = cv2.calcHist([lbp_hist.astype(np.uint8)], [0], None, [256], [0, 256])
        hist = cv2.normalize(hist, hist).flatten()

        id, conf = recognizer.predict(face) # Melakukan pengenalan wajah

        if conf < threshold:
            if id == 1:
                id = 'Syahrul'
            elif id == 2:
                id = 'Septian'
            elif id == 3:
                id = 'Wildan'
            elif id == 4:
                id = 'Fajar'
            elif id == 5:
                id = 'Arif'
            elif id == 6:
                id = 'Lisa'
            elif id == 7:
                id = 'Ayu'
            elif id == 8:
                id = 'Can'
            elif id == 9:
                id = 'Farras'
            elif id == 10:
                id = 'Fhrezha'
            color = (0, 255, 0)  # Warna hijau untuk wajah terdeteksi

        else:
            id = 'Unknown'
            color = (255, 0, 0) # Warna biru untuk label unknown

        # Menggambar kotak di sekitar wajah yang terdeteksi dan menampilkan nama serta tingkat kepercayaan
        cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        text = f'{id} - Confidence: {conf:.2f}'
        cv2.putText(frame, text, (x+5, y-7), cv2.FONT_HERSHEY_DUPLEX, 0.6, color)

        # Menyimpan label sebenarnya dan prediksi
        true_labels.append(id)
        predicted_labels.append(id)

    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)     # Mengonversi frame BGR ke format RGB
    img = Image.fromarray(img)     # Mengonversi citra NumPy ke objek citra PIL
    img_tk = ImageTk.PhotoImage(image=img)     # Mengonversi citra PIL ke format yang dapat digunakan oleh Tkinter

    label.imgtk = img_tk     # Mengikat citra ke label tkinter
    label.configure(image=img_tk)     # Mengatur citra dalam label untuk ditampilkan di jendela aplikasi

    label.after(10, update_frame)     # Memanggil fungsi update_frame() lagi setelah 10 milidetik untuk menciptakan efek real-time

update_frame() # Memulai proses pemrosesan frame

root.mainloop() # Memulai loop utama Tkinter untuk menjalankan aplikasi

video.release() # Melepaskan kamera dan menghentikan perekaman video
cv2.destroyAllWindows() # Menghancurkan semua jendela OpenCV yang aktif