import cv2
import os
import numpy as np
from PIL import Image
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Membuat variabel recognizer untuk melatih model dg LBPH
recognizer = cv2.face.LBPHFaceRecognizer_create()

# Untuk detector wajah menggunakan file haarcascade_frontalface_default.xml
detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

# Membuat fungsi dengan  getImagesWithLabels parameter path
def getImagesWithLabels(path):
    # Mengambil gambar dari path
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]

    # Membuat variabel baru untuk wajah dan id
    faceSamples = []
    Ids = []

    # for untuk perulangan imagePath yang ada pada imagePaths
    for imagePath in imagePaths:
        # Mengubah gambar menjadi citra grayscale dengan convert L (jika belum grayscale)
        pilImage = Image.open(imagePath).convert('L')

        # Mengkonversi citra grayscale ke format NumPy array dengan tipe data 'uint8'
        imageNp = np.array(pilImage, 'uint8')
        Id = int(os.path.split(imagePath)[-1].split(".")[1])

        # Menggunakan detector wajah untuk deteksi wajah di citra
        faces = detector.detectMultiScale(imageNp)
        for (x, y, w, h) in faces:
            # Jika wajah kedeteksi, wajah disimpan di facesamples, id di ids
            faceSamples.append(imageNp[y:y+h, x:x+w])
            Ids.append(Id) #menyimpan id yg sesuai dengan citra

    # Return untuk mengembalikan nilai
    return faceSamples, Ids

# Membagi data menjadi data training dan data testing
faces, Ids = getImagesWithLabels('datalatih')
X_train, X_test, y_train, y_test = train_test_split(faces, Ids, test_size=0.2, random_state=42)

# Melatih model recognizer
recognizer.train(X_train, np.array(y_train)) #OpenCV otomatis melaksanakan semua proses ekstraksi LBP dari citra wajah dalam x_train dan hitung histogram LBPH

# Simpan model recognizer
recognizer.save('datalatih/training.xml')

# Menghitung akurasi model pada data latih
predicted_train_labels = []
for train_face in X_train:
    label, _ = recognizer.predict(train_face)
    predicted_train_labels.append(label)

train_accuracy = accuracy_score(y_train, predicted_train_labels)
print("Akurasi pada data training :", train_accuracy)

# Melakukan prediksi pada data testing
predicted_labels = []
for test_face in X_test:
    label, _ = recognizer.predict(test_face)
    predicted_labels.append(label)

# Menghitung akurasi
accuracy = accuracy_score(y_test, predicted_labels)
print("Akurasi pada data Testing :", accuracy)


# Hitung classification report
class_report = classification_report(y_test, predicted_labels)

# Tampilkan classification report
print("Classification Report:")
print(class_report)