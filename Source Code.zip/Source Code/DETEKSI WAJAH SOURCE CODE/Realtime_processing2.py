import cv2
import numpy as np

# 0 = kamera internal laptop
camera = 0

# membuka webcam
video = cv2.VideoCapture(camera, cv2.CAP_DSHOW)

# algoritma viola : menggunakan file xml berisi fitur penting wajah manusia
faceDeteksi = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# mengambil id -> untuk memberi label pada gambar wajah yang diambil jadi dapat diidentifikasi siapa yang ada pada gambar.
id = input('Id : ')
a = 0

#looping setiap frame untuk dibaca
while True: 
    a = a + 1
    check, frame = video.read() 
    # membuat mode pengambilan gambar pada scan menjadi Gray (abu-abu)
    abu = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Mendeteksi wajah 
    wajah = faceDeteksi.detectMultiScale(abu,1.3,5)
    print(wajah) #mengoutputkan wajah

    #jika wajah terdeteksi maka looping mengambil citra wajah dari frame dan menyimpannya dalam folder 'datatesting' dengan nama file dan ID pengguna dan nomor iterasi.
    for(x,y,w,h) in wajah:
        face_roi = abu[y:y+h, x:x+w]
        # Membuat file foto ke folder Dataset/ dengan identifikasi Id dan perulangan a
        cv2.imwrite('datalatih/User.'+str(id)+'.'+str(a)+'.jpg', abu[y:y+h,x:x+w])

        # Flip horizontal
        flipped_face = cv2.flip(face_roi, 1)
        cv2.imwrite('datalatih/User.' + str(id) + '.' + str(a) + '_flipped.jpg', flipped_face)

        # Mengenali bentuk wajah (kotak warna hijau di wajah)
        cv2.rectangle(frame, (x,y),(x+w,y+h), (0,255,0),2)
        
    # Nama Window 
    cv2.imshow("Face Recognation Window", frame)
    
    # Perulangan dilakukan hingga 100 pengambilan foto
    if (a > 99):
        break
    
# Cam berhenti
video.release()

# Resize semua gambar menjadi 128x128
for i in range(1, a+1):
    for suffix in ['', '_flipped']:
        img_path = 'datalatih/User.' + str(id) + '.' + str(i) + suffix + '.jpg'
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        
        if img is not None and img.shape[0] > 0 and img.shape[1] > 0:
            resized_img = cv2.resize(img, (128, 128))
            cv2.imwrite(img_path, resized_img)
        else:
            print(f"Failed to read or resize {img_path}")

cv2.destroyAllWindows()